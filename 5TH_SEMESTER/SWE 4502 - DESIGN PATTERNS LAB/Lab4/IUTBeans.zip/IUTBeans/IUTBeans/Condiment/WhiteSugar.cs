﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IUTBeans
{
    internal class WhiteSugar:ICondiment

    {
        

        public string Name()
        {
            return "White Sugar";
        }

        public double Price()
        {
            return 15.00;
        }
    }
}
